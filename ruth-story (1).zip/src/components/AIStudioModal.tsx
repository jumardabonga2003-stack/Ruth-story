import React, { useState } from 'react';
import { Sparkles, BookOpen, Wand2, Loader2, Image as ImageIcon, Plus, Check } from 'lucide-react';
import { Story, Chapter } from '../types';

interface AIStudioModalProps {
  onStoryCreated: (newStory: Story) => void;
  onClose: () => void;
}

export const AIStudioModal: React.FC<AIStudioModalProps> = ({ onStoryCreated, onClose }) => {
  const [prompt, setPrompt] = useState('Uma conversa entre Ruth e Noemi sobre a esperança nos campos de Belém');
  const [characterName, setCharacterName] = useState('Ruth');
  const [genre, setGenre] = useState<'Romance Histórico' | 'Saga Principal' | 'Bíblico' | 'Reflexões'>('Romance Histórico');
  const [style, setStyle] = useState('Poético e Inspirador');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedStory, setGeneratedStory] = useState<{
    title: string;
    synopsis: string;
    content: string;
    moral?: string;
  } | null>(null);

  const [coverUrl, setCoverUrl] = useState('https://images.unsplash.com/photo-1509021436468-d510300e5720?auto=format&fit=crop&w=800&q=80');
  const [isGeneratingCover, setIsGeneratingCover] = useState(false);

  const handleGenerateStory = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, genre, style, characterName }),
      });
      const data = await response.json();

      if (data.success) {
        setGeneratedStory({
          title: data.title || `A Jornada de ${characterName}`,
          synopsis: data.synopsis || `Capítulo especial gerado por Inteligência Artificial no RUTH STORY.`,
          content: data.content || `Texto do capítulo gerado com sucesso.`,
          moral: data.moral,
        });
      } else {
        alert(`Não foi possível gerar no momento: ${data.error || 'Tente novamente'}`);
      }
    } catch (err: any) {
      console.error(err);
      alert('Erro ao se comunicar com o estúdio de IA.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateCover = async () => {
    setIsGeneratingCover(true);
    try {
      const response = await fetch('/api/ai/generate-cover', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: generatedStory?.title || prompt }),
      });
      const data = await response.json();
      if (data.success && data.imageUrl) {
        setCoverUrl(data.imageUrl);
      } else {
        alert('Capa padrão mantida. (Requer chave Gemini ativa)');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingCover(false);
    }
  };

  const handleSaveToLibrary = () => {
    if (!generatedStory) return;

    const newChapter: Chapter = {
      id: `ai-chap-${Date.now()}`,
      chapterNumber: 1,
      title: generatedStory.title,
      synopsis: generatedStory.synopsis,
      content: `${generatedStory.content}\n\n― Reflexão: ${generatedStory.moral || 'A fidelidade em pequenas coisas constrói grandiosos destinos.'}`,
      estimatedReadTime: '5 min de leitura',
    };

    const newStory: Story = {
      id: `ai-story-${Date.now()}`,
      title: generatedStory.title,
      synopsis: generatedStory.synopsis,
      coverUrl: coverUrl,
      category: genre,
      author: 'Criador IA (Ruth Story Studio)',
      rating: 5.0,
      readCount: 1,
      chapters: [newChapter],
      audioAvailable: true,
      isExclusive: true,
      publishedDate: 'Hoje',
      tags: ['Criação IA', 'Exclusivo', genre],
    };

    onStoryCreated(newStory);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      <div className="bg-[#111111] border border-white/10 rounded-[32px] p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#25D366]/5 rounded-full blur-3xl pointer-events-none" />

        {/* Title */}
        <div className="flex items-center gap-4 mb-8 border-b border-white/5 pb-5">
          <div className="w-12 h-12 rounded-2xl bg-[#25D366]/10 border border-[#25D366]/30 flex items-center justify-center text-2xl text-[#25D366] shrink-0">
            <Sparkles className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black font-syne text-white uppercase tracking-tight flex items-center gap-2">
              Estúdio de Criação IA
            </h2>
            <p className="text-xs uppercase tracking-widest text-white/50 font-semibold mt-0.5">
              Escreva novos capítulos inspiradores e expansões oficiais para a saga RUTH STORY com apoio de IA.
            </p>
          </div>
        </div>

        {/* Form Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-black text-[#25D366] uppercase tracking-[0.15em] mb-1.5">
                Tema / Ideia Central do Capítulo
              </label>
              <textarea
                rows={3}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ex: Ruth e Boaz conversando na eira sobre lealdade..."
                className="w-full bg-[#181818] border border-white/10 focus:border-[#25D366] text-xs font-medium text-white p-3.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#25D366]"
              />
            </div>

            <div>
              <label className="block text-xs font-black text-[#25D366] uppercase tracking-[0.15em] mb-1.5">
                Personagem Principal
              </label>
              <input
                type="text"
                value={characterName}
                onChange={(e) => setCharacterName(e.target.value)}
                className="w-full bg-[#181818] border border-white/10 focus:border-[#25D366] text-xs font-medium text-white px-3.5 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#25D366]"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-black text-[#25D366] uppercase tracking-[0.15em] mb-1.5">
                Categoria da História
              </label>
              <select
                value={genre}
                onChange={(e: any) => setGenre(e.target.value)}
                className="w-full bg-[#181818] border border-white/10 focus:border-[#25D366] text-xs font-medium text-white px-3.5 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#25D366]"
              >
                <option value="Romance Histórico">Romance Histórico</option>
                <option value="Saga Principal">Saga Principal</option>
                <option value="Bíblico">Bíblico</option>
                <option value="Reflexões">Reflexões</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-black text-[#25D366] uppercase tracking-[0.15em] mb-1.5">
                Estilo Narrativo
              </label>
              <input
                type="text"
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                placeholder="Ex: Poético, Emocionante, Épico..."
                className="w-full bg-[#181818] border border-white/10 focus:border-[#25D366] text-xs font-medium text-white px-3.5 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#25D366]"
              />
            </div>

            <button
              disabled={isGenerating || !prompt.trim()}
              onClick={handleGenerateStory}
              className="w-full flex items-center justify-center gap-3 bg-[#25D366] hover:bg-[#1ebe5d] disabled:opacity-50 text-black font-black uppercase tracking-[0.1em] py-4 rounded-xl text-xs sm:text-sm shadow-xl shadow-[#25D366]/20 transition-all hover:scale-[1.02] active:scale-95"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Escrevendo Capítulo com IA...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5 stroke-[2.5]" />
                  <span>Gerar Capítulo com IA</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Generated Result Output */}
        {generatedStory && (
          <div className="bg-[#161616] border border-[#25D366]/40 rounded-[24px] p-6 space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
              <div>
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#25D366] bg-[#25D366]/10 px-3 py-1 rounded-full border border-[#25D366]/30">
                  Capítulo Gerado com Sucesso
                </span>
                <h3 className="text-xl font-black font-syne text-white mt-2 uppercase tracking-tight">
                  {generatedStory.title}
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleGenerateCover}
                  disabled={isGeneratingCover}
                  className="flex items-center gap-2 bg-[#202020] hover:bg-[#282828] border border-white/10 text-xs font-bold uppercase tracking-wider text-white px-4 py-2.5 rounded-xl"
                >
                  {isGeneratingCover ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4 text-amber-400" />}
                  <span>Gerar Capa</span>
                </button>

                <button
                  onClick={handleSaveToLibrary}
                  className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-black font-black text-xs uppercase tracking-wider px-5 py-2.5 rounded-xl transition-all shadow-md"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Salvar na Biblioteca</span>
                </button>
              </div>
            </div>

            {/* Cover Preview + Content */}
            <div className="flex flex-col md:flex-row gap-6">
              <div className="w-full md:w-48 shrink-0">
                <img
                  src={coverUrl}
                  alt="Capa gerada"
                  className="w-full h-64 object-cover rounded-2xl border border-white/10 shadow-md"
                />
              </div>

              <div className="flex-1 space-y-4 text-white/80 text-sm leading-relaxed max-h-96 overflow-y-auto pr-2">
                <p className="text-xs text-white/50 italic bg-[#1c1c1c] p-3.5 rounded-xl border border-white/5">
                  "{generatedStory.synopsis}"
                </p>

                {generatedStory.content.split('\n\n').map((para, i) => (
                  <p key={i} className="indent-4 text-justify font-sans">
                    {para}
                  </p>
                ))}

                {generatedStory.moral && (
                  <div className="bg-[#25D366]/10 border-l-4 border-[#25D366] p-3.5 rounded-r-xl text-xs text-[#25D366] font-bold">
                    💡 Reflexão: {generatedStory.moral}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
