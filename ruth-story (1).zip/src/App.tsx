import React, { useState, useEffect } from 'react';
import { 
  BookOpen, Download, Star, Heart, Play, Sparkles, Filter, 
  Smartphone, ShieldCheck, Check, ArrowRight, BookMarked, Radio, Volume2, Search 
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { DownloadView } from './components/DownloadView';
import { ReaderModal } from './components/ReaderModal';
import { StoryDetailModal } from './components/StoryDetailModal';
import { AIStudioModal } from './components/AIStudioModal';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { INITIAL_STORIES, OFFICIAL_APP_RELEASE } from './data/stories';
import { Story } from './types';

export default function App() {
  const [stories, setStories] = useState<Story[]>(() => {
    const saved = localStorage.getItem('ruth_stories_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved stories', e);
      }
    }
    return INITIAL_STORIES;
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('ruth_favorites');
    return saved ? JSON.parse(saved) : ['ruth-saga-principal'];
  });

  const [activeTab, setActiveTab] = useState<'library' | 'download' | 'favorites' | 'studio'>('library');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active modals / players state
  const [selectedStoryForDetail, setSelectedStoryForDetail] = useState<Story | null>(null);
  const [activeReaderStory, setActiveReaderStory] = useState<{ story: Story; chapterIdx: number } | null>(null);
  const [activeAudio, setActiveAudio] = useState<{ story: Story; chapterIdx: number } | null>(null);

  // Save stories to localStorage
  useEffect(() => {
    localStorage.setItem('ruth_stories_v1', JSON.stringify(stories));
  }, [stories]);

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem('ruth_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (storyId: string) => {
    setFavorites((prev) =>
      prev.includes(storyId) ? prev.filter((id) => id !== storyId) : [...prev, storyId]
    );
  };

  const handleAddNewStoryFromAI = (newStory: Story) => {
    setStories([newStory, ...stories]);
    setActiveTab('library');
    setSelectedStoryForDetail(newStory);
  };

  // Filter logic
  const categories = ['Todos', 'Saga Principal', 'Romance Histórico', 'Bíblico', 'Reflexões', 'Audiobook'];

  const filteredStories = stories.filter((story) => {
    const matchesTab = activeTab === 'favorites' ? favorites.includes(story.id) : true;
    const matchesCategory = selectedCategory === 'Todos' || story.category === selectedCategory;
    const matchesSearch = searchQuery
      ? story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.synopsis.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
      : true;

    return matchesTab && matchesCategory && matchesSearch;
  });

  const featuredStory = stories.find((s) => s.id === 'ruth-saga-principal') || stories[0];

  return (
    <div className="min-h-screen bg-[#080808] text-[#E5E5E5] font-sans flex flex-col relative overflow-x-hidden selection:bg-[#25D366] selection:text-black">
      
      {/* Background ambient glows matching Bold Typography theme */}
      <div className="fixed top-[-150px] right-[-100px] w-[500px] h-[500px] bg-[#25D366] opacity-[0.06] rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="fixed bottom-[-100px] left-[-100px] w-[400px] h-[400px] bg-[#1a1a1a] opacity-30 rounded-full blur-[100px] pointer-events-none z-0" />

      {/* App Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        favoritesCount={favorites.length}
        onOpenReaderForFeatured={() => setActiveReaderStory({ story: featuredStory, chapterIdx: 0 })}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-24 z-10">
        {activeTab === 'download' ? (
          <DownloadView onBackToApp={() => setActiveTab('library')} />
        ) : activeTab === 'studio' ? (
          <AIStudioModal
            onStoryCreated={handleAddNewStoryFromAI}
            onClose={() => setActiveTab('library')}
          />
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
            
            {/* Featured Hero Banner - Bold Typography Theme */}
            {activeTab === 'library' && !searchQuery && selectedCategory === 'Todos' && (
              <section className="relative rounded-[32px] overflow-hidden border border-white/10 bg-[#111111] shadow-2xl group">
                <div className="absolute inset-0 z-0 opacity-30 mix-blend-overlay pointer-events-none transition-opacity group-hover:opacity-40">
                  <img
                    src={featuredStory.coverUrl}
                    alt={featuredStory.title}
                    className="w-full h-full object-cover scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-r from-[#080808] via-[#080808]/95 to-transparent z-0" />

                <div className="relative z-10 p-8 sm:p-14 max-w-3xl space-y-6">
                  <div className="inline-block px-3.5 py-1 border border-[#25D366]/30 rounded-full bg-[#25D366]/10">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-[#25D366] font-extrabold">
                      Official Feature • Saga Principal
                    </span>
                  </div>

                  <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-syne text-white tracking-tighter uppercase leading-[0.88]">
                    {featuredStory.title}
                  </h1>

                  <p className="text-white/60 text-base sm:text-lg leading-relaxed font-sans max-w-xl border-l-2 border-[#25D366]/40 pl-6">
                    {featuredStory.synopsis}
                  </p>

                  <div className="flex flex-wrap items-center gap-4 pt-4">
                    <button
                      onClick={() => setActiveReaderStory({ story: featuredStory, chapterIdx: 0 })}
                      className="group relative inline-flex items-center gap-3 bg-[#25D366] hover:bg-[#1ebe5d] text-black font-black uppercase tracking-[0.1em] px-8 py-4 rounded-2xl text-sm sm:text-base shadow-xl shadow-[#25D366]/20 transition-all hover:scale-[1.02] active:scale-95"
                    >
                      <BookOpen className="w-5 h-5 stroke-[2.5]" />
                      <span>LER CAPÍTULO I AGORA</span>
                    </button>

                    <button
                      onClick={() => setActiveAudio({ story: featuredStory, chapterIdx: 0 })}
                      className="flex items-center gap-2 bg-[#181818] hover:bg-[#222222] border border-white/10 text-white font-bold uppercase tracking-wider px-6 py-4 rounded-2xl text-xs sm:text-sm transition-all"
                    >
                      <Volume2 className="w-5 h-5 text-[#25D366]" />
                      <span>Ouvir Audiobook</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('download')}
                      className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#25D366] hover:underline px-3 py-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>Baixar App (RUTH-STORY.zip)</span>
                    </button>
                  </div>
                </div>
              </section>
            )}

            {/* Categories & Filter Bar */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-white/5 pb-6">
              <div>
                <h2 className="text-2xl sm:text-3xl font-black font-syne text-white tracking-tight uppercase flex items-center gap-3">
                  {activeTab === 'favorites' ? 'Sua Lista de Favoritos' : 'Biblioteca de Histórias'}
                </h2>
                <p className="text-xs uppercase tracking-widest text-white/40 font-semibold mt-1">
                  {filteredStories.length} {filteredStories.length === 1 ? 'história disponível' : 'histórias disponíveis'}
                </p>
              </div>

              {/* Category Pills - Bold Typography style */}
              <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2.5 rounded-xl text-[10px] font-extrabold uppercase tracking-[0.2em] whitespace-nowrap transition-all border ${
                      selectedCategory === cat
                        ? 'bg-[#25D366] text-black border-[#25D366] shadow-lg shadow-[#25D366]/20'
                        : 'bg-[#111111] text-white/70 border-white/10 hover:border-white/20 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Stories Grid - Bold Typography cards */}
            {filteredStories.length === 0 ? (
              <div className="text-center py-20 bg-[#111111] rounded-[32px] border border-white/5 p-8">
                <div className="text-4xl mb-3">📖</div>
                <h3 className="text-xl font-bold font-syne uppercase text-white mb-1">Nenhuma história encontrada</h3>
                <p className="text-xs text-white/50 mb-6">
                  {activeTab === 'favorites'
                    ? 'Você ainda não marcou nenhuma história como favorita.'
                    : 'Tente alterar os termos da busca ou selecionar outra categoria.'}
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('Todos');
                    setSearchQuery('');
                  }}
                  className="bg-[#181818] text-[#25D366] border border-[#25D366]/40 px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-[#25D366]/10"
                >
                  Limpar Filtros
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredStories.map((story) => {
                  const isFav = favorites.includes(story.id);
                  return (
                    <div
                      key={story.id}
                      className="group bg-[#111111] border border-white/5 hover:border-[#25D366]/40 rounded-[28px] overflow-hidden shadow-2xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
                    >
                      {/* Image header */}
                      <div className="relative h-56 overflow-hidden bg-[#080808] cursor-pointer" onClick={() => setSelectedStoryForDetail(story)}>
                        <img
                          src={story.coverUrl}
                          alt={story.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent opacity-90" />
                        
                        <div className="absolute top-4 left-4 flex items-center gap-2">
                          <span className="bg-black/90 text-[#25D366] text-[9px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full border border-[#25D366]/30">
                            {story.category}
                          </span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(story.id);
                          }}
                          className="absolute top-4 right-4 p-2.5 rounded-full bg-black/70 hover:bg-black text-white border border-white/10 transition-colors"
                        >
                          <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : 'text-white/60'}`} />
                        </button>

                        <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white/70 font-mono">
                          <div className="flex items-center gap-1.5 text-amber-400 font-bold bg-black/80 px-2.5 py-1 rounded-lg border border-white/5 backdrop-blur">
                            <Star className="w-3.5 h-3.5 fill-amber-400" />
                            <span>{story.rating}</span>
                          </div>
                          <span className="bg-black/80 px-2.5 py-1 rounded-lg text-[10px] uppercase tracking-wider font-bold text-white/50 border border-white/5">
                            {story.chapters.length} cap.
                          </span>
                        </div>
                      </div>

                      {/* Card Info */}
                      <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                        <div>
                          <h3 
                            onClick={() => setSelectedStoryForDetail(story)}
                            className="font-syne font-extrabold text-xl text-white group-hover:text-[#25D366] transition-colors cursor-pointer tracking-tight line-clamp-1 uppercase"
                          >
                            {story.title}
                          </h3>
                          <p className="text-xs text-white/50 mt-2 line-clamp-2 leading-relaxed">
                            {story.synopsis}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="pt-3 border-t border-white/5 flex items-center gap-3">
                          <button
                            onClick={() => setActiveReaderStory({ story, chapterIdx: 0 })}
                            className="flex-1 flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-black text-xs font-black uppercase tracking-[0.1em] py-3 rounded-xl transition-all shadow-md"
                          >
                            <BookOpen className="w-3.5 h-3.5 stroke-[2.5]" />
                            <span>Ler Agora</span>
                          </button>

                          {story.audioAvailable && (
                            <button
                              onClick={() => setActiveAudio({ story, chapterIdx: 0 })}
                              className="p-3 rounded-xl bg-[#181818] hover:bg-[#222222] text-[#25D366] border border-white/10 transition-all"
                              title="Ouvir Áudio"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* APK Download Banner Footer */}
            <section className="bg-[#111111] border border-white/10 rounded-[32px] p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
              <div className="max-w-2xl mx-auto space-y-5 relative z-10">
                <div className="inline-flex items-center gap-2 bg-[#25D366]/10 border border-[#25D366]/30 text-[#25D366] text-[10px] font-black px-3.5 py-1 rounded-full uppercase tracking-[0.2em]">
                  <Smartphone className="w-4 h-4" />
                  <span>Aplicativo Oficial RUTH STORY</span>
                </div>

                <h3 className="text-3xl sm:text-4xl font-black text-white font-syne uppercase tracking-tight">
                  Instale o App no seu Celular Android
                </h3>

                <p className="text-white/60 text-sm leading-relaxed">
                  Baixe o arquivo oficial compactado <strong className="text-[#25D366] font-bold">RUTH-STORY.zip</strong> e leve suas histórias e audiobooks favoritos para qualquer lugar sem depender de internet.
                </p>

                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('download')}
                    className="inline-flex items-center gap-3 bg-[#25D366] hover:bg-[#1ebe5d] text-black text-sm sm:text-base font-black uppercase tracking-[0.1em] px-8 py-4 rounded-2xl shadow-xl shadow-[#25D366]/20 transition-all transform hover:scale-[1.02] active:scale-95"
                  >
                    <Download className="w-5 h-5 stroke-[2.5]" />
                    <span>BAIXAR PACOTE OFICIAL (.ZIP)</span>
                  </button>
                </div>
              </div>
            </section>

          </div>
        )}
      </main>

      {/* Reader Modal */}
      {activeReaderStory && (
        <ReaderModal
          story={activeReaderStory.story}
          initialChapterIndex={activeReaderStory.chapterIdx}
          onClose={() => setActiveReaderStory(null)}
          isFavorite={favorites.includes(activeReaderStory.story.id)}
          onToggleFavorite={toggleFavorite}
        />
      )}

      {/* Story Detail Modal */}
      {selectedStoryForDetail && (
        <StoryDetailModal
          story={selectedStoryForDetail}
          onClose={() => setSelectedStoryForDetail(null)}
          onOpenReader={(idx) => {
            const story = selectedStoryForDetail;
            setSelectedStoryForDetail(null);
            setActiveReaderStory({ story, chapterIdx: idx });
          }}
          isFavorite={favorites.includes(selectedStoryForDetail.id)}
          onToggleFavorite={toggleFavorite}
        />
      )}

      {/* Audio Player Bar */}
      {activeAudio && (
        <AudioPlayerBar
          story={activeAudio.story}
          chapter={activeAudio.story.chapters[activeAudio.chapterIdx]}
          onClose={() => setActiveAudio(null)}
        />
      )}

      {/* App Footer */}
      <footer className="bg-[#080808] border-t border-white/5 py-10 px-4 text-center text-xs text-white/40 space-y-3 z-10">
        <p className="font-syne text-white font-black text-base uppercase tracking-[0.2em]">
          RUTH STORY ― Publishing Suite
        </p>
        <p className="text-[10px] uppercase tracking-widest">Histórias exclusivas e e-reader interativo • Versão {OFFICIAL_APP_RELEASE.version}</p>
        <div className="flex items-center justify-center gap-6 text-[10px] font-bold uppercase tracking-[0.2em] text-[#25D366]/70 pt-2">
          <button onClick={() => setActiveTab('library')} className="hover:text-[#25D366]">Biblioteca</button>
          <span>•</span>
          <button onClick={() => setActiveTab('download')} className="hover:text-[#25D366]">Baixar App</button>
          <span>•</span>
          <button onClick={() => setActiveTab('studio')} className="hover:text-[#25D366]">Criador IA</button>
        </div>
      </footer>
    </div>
  );
}
