export interface Chapter {
  id: string;
  chapterNumber: number;
  title: string;
  content: string;
  synopsis?: string;
  audioUrl?: string;
  estimatedReadTime: string;
}

export interface Story {
  id: string;
  title: string;
  synopsis: string;
  coverUrl: string;
  category: 'Saga Principal' | 'Romance Histórico' | 'Bíblico' | 'Reflexões' | 'Audiobook';
  author: string;
  rating: number;
  readCount: number;
  chapters: Chapter[];
  audioAvailable: boolean;
  isExclusive: boolean;
  publishedDate: string;
  tags: string[];
}

export interface UserReadingProgress {
  storyId: string;
  chapterId: string;
  chapterIndex: number;
  progressPercent: number;
  lastReadDate: string;
}

export interface Comment {
  id: string;
  storyId: string;
  authorName: string;
  avatar: string;
  text: string;
  date: string;
  likes: number;
  verifiedReader?: boolean;
}

export interface ReaderSettings {
  fontSize: number; // 14 to 26
  lineHeight: number; // 1.4 to 2.2
  fontFamily: 'serif' | 'sans' | 'cinzel';
  theme: 'dark' | 'sepia' | 'black';
  autoScrollSpeed: number; // 0 (off) to 5
}

export interface AppRelease {
  version: string;
  buildDate: string;
  size: string;
  downloads: number;
  changes: string[];
  downloadUrl: string;
}
