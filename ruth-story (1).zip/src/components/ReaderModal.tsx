import React, { useState, useEffect, useRef } from 'react';
import { 
  X, ChevronLeft, ChevronRight, Volume2, VolumeX, Settings, 
  BookOpen, Bookmark, BookmarkCheck, Play, Pause, RefreshCw, Sparkles, Sliders
} from 'lucide-react';
import { Story, Chapter, ReaderSettings } from '../types';

interface ReaderModalProps {
  story: Story;
  initialChapterIndex?: number;
  onClose: () => void;
  onToggleFavorite?: (storyId: string) => void;
  isFavorite?: boolean;
}

export const ReaderModal: React.FC<ReaderModalProps> = ({
  story,
  initialChapterIndex = 0,
  onClose,
  onToggleFavorite,
  isFavorite = false,
}) => {
  const [currentChapterIdx, setCurrentChapterIdx] = useState(initialChapterIndex);
  const [showSettings, setShowSettings] = useState(false);
  const [showTOC, setShowTOC] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  
  // Audio narration state
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Settings
  const [settings, setSettings] = useState<ReaderSettings>({
    fontSize: 18,
    lineHeight: 1.8,
    fontFamily: 'serif',
    theme: 'dark',
    autoScrollSpeed: 0,
  });

  const contentRef = useRef<HTMLDivElement>(null);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  const chapter = story.chapters[currentChapterIdx] || story.chapters[0];

  // Restore saved bookmark/settings
  useEffect(() => {
    const saved = localStorage.getItem(`bookmark_${story.id}`);
    if (saved) {
      const idx = parseInt(saved, 10);
      if (!isNaN(idx) && idx < story.chapters.length) {
        setIsBookmarked(idx === currentChapterIdx);
      }
    }
  }, [story.id, currentChapterIdx]);

  // Handle Speech Narration (Web Speech API as immediate robust fallback)
  const toggleSpeech = () => {
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    if (!('speechSynthesis' in window)) {
      setAudioError('Sintetizador de voz não suportado neste navegador.');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(chapter.content);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      setIsPlayingAudio(true);
      setAudioError(null);
    };

    utterance.onend = () => {
      setIsPlayingAudio(false);
    };

    utterance.onerror = (e) => {
      console.error('Speech error:', e);
      setIsPlayingAudio(false);
      setAudioError('Erro ao reproduzir voz.');
    };

    speechRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Clean up speech when chapter or modal closes
  useEffect(() => {
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [currentChapterIdx]);

  const toggleBookmark = () => {
    if (isBookmarked) {
      localStorage.removeItem(`bookmark_${story.id}`);
      setIsBookmarked(false);
    } else {
      localStorage.setItem(`bookmark_${story.id}`, currentChapterIdx.toString());
      setIsBookmarked(true);
    }
  };

  // Theme Styles
  const themeStyles = {
    dark: 'bg-[#0e0e0e] text-slate-200 border-[#222222]',
    sepia: 'bg-[#f4ecd8] text-[#433422] border-[#e2d5bd]',
    black: 'bg-black text-slate-300 border-[#1a1a1a]',
  };

  const fontFamilies = {
    serif: 'font-serif-book',
    sans: 'font-sans',
    cinzel: 'font-cinzel',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-0 sm:p-4 overflow-hidden">
      <div className={`w-full h-full sm:max-w-4xl sm:h-[92vh] sm:rounded-3xl flex flex-col shadow-2xl border ${themeStyles[settings.theme]} transition-colors duration-300 relative`}>
        
        {/* Header Bar */}
        <header className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-inherit bg-inherit/80 backdrop-blur shrink-0 z-10">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-white/10 transition-colors"
              title="Fechar leitor"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>
            <div className="truncate">
              <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-[#25D366] truncate">
                {story.title}
              </h2>
              <p className="text-sm font-black font-syne uppercase truncate text-white">
                Capítulo {chapter.chapterNumber}: {chapter.title}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Audio narration toggle */}
            <button
              onClick={toggleSpeech}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all ${
                isPlayingAudio
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40 hover:bg-[#25D366]/30'
              }`}
            >
              {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{isPlayingAudio ? 'Parar Áudio' : 'Ouvir Capítulo'}</span>
            </button>

            {/* Bookmark button */}
            <button
              onClick={toggleBookmark}
              className={`p-2 rounded-xl transition-colors ${
                isBookmarked ? 'text-[#25D366] bg-[#25D366]/10' : 'opacity-70 hover:opacity-100'
              }`}
              title={isBookmarked ? 'Marcador salvo' : 'Marcar capítulo'}
            >
              {isBookmarked ? <BookmarkCheck className="w-5 h-5 text-[#25D366]" /> : <Bookmark className="w-5 h-5" />}
            </button>

            {/* TOC Drawer Toggle */}
            <button
              onClick={() => setShowTOC(!showTOC)}
              className="p-2 rounded-xl opacity-80 hover:opacity-100 transition-colors"
              title="Índice de Capítulos"
            >
              <BookOpen className="w-5 h-5" />
            </button>

            {/* Settings Modal Toggle */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-xl opacity-80 hover:opacity-100 transition-colors"
              title="Ajustes de Leitura"
            >
              <Sliders className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Reader Settings Floating Dropdown */}
        {showSettings && (
          <div className="absolute top-16 right-4 z-30 w-72 bg-[#181818] text-slate-100 border border-[#333333] p-4 rounded-2xl shadow-2xl space-y-4 animate-fade-in">
            <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
              <span className="text-xs font-bold uppercase text-[#25D366]">Ajustes do Leitor</span>
              <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Font Size */}
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>Tamanho do Texto</span>
                <span>{settings.fontSize}px</span>
              </div>
              <input
                type="range"
                min="14"
                max="28"
                value={settings.fontSize}
                onChange={(e) => setSettings({ ...settings, fontSize: parseInt(e.target.value, 10) })}
                className="w-full accent-[#25D366]"
              />
            </div>

            {/* Font Family */}
            <div>
              <span className="text-xs text-slate-400 block mb-1">Fonte</span>
              <div className="grid grid-cols-3 gap-1">
                {(['serif', 'sans', 'cinzel'] as const).map((font) => (
                  <button
                    key={font}
                    onClick={() => setSettings({ ...settings, fontFamily: font })}
                    className={`px-2 py-1.5 rounded-lg text-xs font-medium border capitalize ${
                      settings.fontFamily === font
                        ? 'border-[#25D366] text-[#25D366] bg-[#25D366]/10'
                        : 'border-[#333] text-slate-300 hover:bg-[#222]'
                    }`}
                  >
                    {font}
                  </button>
                ))}
              </div>
            </div>

            {/* Theme */}
            <div>
              <span className="text-xs text-slate-400 block mb-1">Tema Visual</span>
              <div className="grid grid-cols-3 gap-1">
                {(['dark', 'sepia', 'black'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setSettings({ ...settings, theme: t })}
                    className={`px-2 py-1.5 rounded-lg text-xs font-medium border capitalize ${
                      settings.theme === t
                        ? 'border-[#25D366] text-[#25D366]'
                        : 'border-[#333] text-slate-300 hover:bg-[#222]'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TOC Drawer Overlay */}
        {showTOC && (
          <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-sm flex justify-start">
            <div className="w-full max-w-xs h-full bg-[#111111] border-r border-[#222222] p-5 flex flex-col space-y-4">
              <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                <h3 className="font-bold text-sm text-[#25D366] uppercase tracking-wider">
                  Índice de Capítulos
                </h3>
                <button onClick={() => setShowTOC(false)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {story.chapters.map((ch, idx) => (
                  <button
                    key={ch.id}
                    onClick={() => {
                      setCurrentChapterIdx(idx);
                      setShowTOC(false);
                    }}
                    className={`w-full text-left p-3 rounded-xl border text-xs transition-all ${
                      idx === currentChapterIdx
                        ? 'border-[#25D366] bg-[#25D366]/10 text-[#25D366] font-bold'
                        : 'border-[#222] text-slate-300 hover:bg-[#1a1a1a]'
                    }`}
                  >
                    <div className="font-semibold text-sm">Capítulo {ch.chapterNumber}</div>
                    <div className="truncate opacity-80">{ch.title}</div>
                    <div className="text-[10px] text-slate-500 mt-1">{ch.estimatedReadTime}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Reader Body Content */}
        <div ref={contentRef} className="flex-1 overflow-y-auto px-6 sm:px-16 py-8 leading-relaxed selection:bg-[#25D366]/30">
          <div className="max-w-2xl mx-auto space-y-6">
            
            {/* Chapter Heading */}
            <div className="text-center border-b border-inherit pb-6 mb-8">
              <span className="text-xs font-bold uppercase tracking-widest text-[#25D366] block mb-1">
                Capítulo {chapter.chapterNumber} de {story.chapters.length}
              </span>
              <h1 className={`text-2xl sm:text-3xl font-bold mb-2 ${fontFamilies[settings.fontFamily]}`}>
                {chapter.title}
              </h1>
              <p className="text-xs opacity-60">{chapter.estimatedReadTime}</p>
            </div>

            {/* Paragraphs */}
            <div 
              style={{ 
                fontSize: `${settings.fontSize}px`, 
                lineHeight: settings.lineHeight 
              }}
              className={`space-y-6 ${fontFamilies[settings.fontFamily]}`}
            >
              {chapter.content.split('\n\n').map((paragraph, pIdx) => (
                <p key={pIdx} className="indent-6 text-justify">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* End of chapter divider */}
            <div className="pt-10 text-center opacity-40">
              <span className="text-xl tracking-widest">✦ ✦ ✦</span>
            </div>
          </div>
        </div>

        {/* Footer Navigation Bar */}
        <footer className="flex items-center justify-between px-6 py-4 border-t border-inherit bg-inherit/80 shrink-0">
          <button
            disabled={currentChapterIdx === 0}
            onClick={() => setCurrentChapterIdx((prev) => Math.max(0, prev - 1))}
            className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider px-4 py-2.5 rounded-xl border border-inherit disabled:opacity-30 hover:bg-white/10 transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Anterior</span>
          </button>

          <span className="text-xs font-mono font-bold tracking-widest opacity-70">
            {currentChapterIdx + 1} / {story.chapters.length}
          </span>

          <button
            disabled={currentChapterIdx === story.chapters.length - 1}
            onClick={() => setCurrentChapterIdx((prev) => Math.min(story.chapters.length - 1, prev + 1))}
            className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider px-5 py-2.5 rounded-xl bg-[#25D366] text-black hover:bg-[#1ebe5d] disabled:opacity-30 transition-all shadow-md"
          >
            <span>Próximo</span>
            <ChevronRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </footer>
      </div>
    </div>
  );
};
