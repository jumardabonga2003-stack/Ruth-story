import React, { useState } from 'react';
import { Download, CheckCircle, Smartphone, ShieldCheck, FileArchive, QrCode, ArrowRight, Share2, Sparkles, Copy, Check } from 'lucide-react';
import { OFFICIAL_APP_RELEASE } from '../data/stories';

interface DownloadViewProps {
  onBackToApp: () => void;
}

export const DownloadView: React.FC<DownloadViewProps> = ({ onBackToApp }) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [downloadStarted, setDownloadStarted] = useState(false);

  const directZipUrl = OFFICIAL_APP_RELEASE.downloadUrl;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin + directZipUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleDownloadClick = () => {
    setDownloadStarted(true);
    const link = document.createElement('a');
    link.href = directZipUrl;
    link.download = 'RUTH-STORY.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-[85vh] py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="w-full max-w-3xl bg-[#111111] p-8 sm:p-12 rounded-[32px] border border-white/10 shadow-[0_0_80px_rgba(37,211,102,0.15)] text-center relative overflow-hidden">
        
        {/* Glow ambient background effect from theme */}
        <div className="absolute top-[-100px] right-[-100px] w-[350px] h-[350px] bg-[#25D366] opacity-[0.08] rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-[-100px] left-[-100px] w-[350px] h-[350px] bg-[#1a1a1a] opacity-30 rounded-full blur-[100px] pointer-events-none" />

        {/* Badge */}
        <div className="inline-block px-4 py-1.5 border border-[#25D366]/30 rounded-full mb-6 bg-[#25D366]/10">
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#25D366] font-extrabold">
            Official Android Client • v{OFFICIAL_APP_RELEASE.version}
          </span>
        </div>

        {/* Massive Bold Typography Title */}
        <h1 className="text-5xl sm:text-7xl md:text-8xl font-black tracking-tighter text-white mb-6 select-none font-syne uppercase leading-[0.85]">
          RUTH<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#25D366] to-[#1ebe5d]">
            STORY.
          </span>
        </h1>

        <p className="max-w-lg text-base sm:text-lg text-white/60 leading-relaxed mb-8 mx-auto border-l-2 border-[#25D366]/50 pl-6 text-left font-medium">
          Baixe agora o aplicativo oficial <strong className="text-white font-bold">RUTH STORY</strong>.<br />
          Histórias exclusivas e áudios imersivos direto no seu celular. Sem anúncios, sem interrupções.
        </p>

        {/* Main Download Button matching Bold Typography Theme */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-10">
          <button
            onClick={handleDownloadClick}
            className="group relative inline-flex items-center justify-center gap-4 bg-[#25D366] px-10 py-5 rounded-2xl text-black font-black text-lg sm:text-xl hover:scale-[1.02] active:scale-95 transition-all shadow-2xl shadow-[#25D366]/25 w-full sm:w-auto"
          >
            <Download className="w-6 h-6 group-hover:translate-y-0.5 transition-transform stroke-[2.5]" />
            <span>DOWNLOAD APP (RUTH-STORY.zip)</span>
          </button>

          <div className="flex flex-col text-left">
            <span className="text-xl font-grotesk font-black text-white">{OFFICIAL_APP_RELEASE.size}</span>
            <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Safe APK Install</span>
          </div>
        </div>

        {downloadStarted && (
          <div className="bg-[#25D366]/10 border border-[#25D366]/40 p-4 rounded-2xl text-xs text-[#25D366] font-bold flex items-center justify-center gap-2 max-w-md mx-auto mb-8 animate-fade-in">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>Download iniciado! Descompacte e instale o pacote oficial.</span>
          </div>
        )}

        {/* Features Checklist */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left bg-[#0d0d0d] p-6 rounded-[24px] border border-white/5 mb-8">
          {OFFICIAL_APP_RELEASE.changes.map((change, idx) => (
            <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-white/80 font-medium">
              <ShieldCheck className="w-4 h-4 text-[#25D366] shrink-0 mt-0.5" />
              <span>{change}</span>
            </div>
          ))}
        </div>

        {/* How to use / Instructions section */}
        <div className="bg-[#0a0a0a] border border-white/5 p-6 rounded-[24px] text-left mb-8">
          <h2 className="text-xs font-black text-[#25D366] uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
            <FileArchive className="w-4 h-4" />
            <span>Como instalar no celular Android:</span>
          </h2>
          <ol className="list-decimal list-inside text-xs text-white/70 space-y-2 leading-relaxed font-medium">
            <li>Baixe o arquivo <code className="bg-[#181818] text-[#25D366] px-2 py-0.5 rounded font-mono border border-white/10">RUTH-STORY.zip</code> usando o botão acima.</li>
            <li>Extraia o conteúdo da pasta compactada na memória do seu celular.</li>
            <li>Abra o arquivo de instalação ou abra diretamente no navegador.</li>
            <li>Aproveite a leitura ilimitada e os áudios imersivos mesmo offline!</li>
          </ol>
        </div>

        {/* Direct Link Share options */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-white/5">
          <button
            onClick={handleCopyLink}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-[#161616] hover:bg-[#222222] border border-white/10 text-xs font-bold uppercase tracking-wider text-white px-5 py-3 rounded-xl transition-colors"
          >
            {copiedLink ? <Check className="w-4 h-4 text-[#25D366]" /> : <Copy className="w-4 h-4" />}
            <span>{copiedLink ? 'Link Copiado!' : 'Copiar Link Direto (.ZIP)'}</span>
          </button>

          <button
            onClick={onBackToApp}
            className="w-full sm:w-auto flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider text-[#25D366] hover:underline py-2"
          >
            <span>Usar Leitor Web Agora</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-8 text-[10px] uppercase tracking-[0.3em] text-white/30 font-semibold">
          Verified by Play Protect • © 2026 Ruth Story Collective
        </div>
      </div>
    </div>
  );
};
