import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initializer for Gemini
let aiClient: GoogleGenAI | null = null;
function getGenAI() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not set. AI features will run in mock fallback mode.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health Check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", appName: "RUTH STORY" });
});

// Download App ZIP / Package endpoint
app.get("/api/download/RUTH-STORY.zip", (_req, res) => {
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", "attachment; filename=RUTH-STORY-v1.0.zip");
  
  // A clean synthetic zip header buffer with dummy manifest/app files for the simulated installer
  const zipContent = Buffer.from(
    "RUTH STORY OFFICIAL APP BUNDLE v1.0.0\n------------------------------------\nPackage ID: com.ruthstory.app.official\nPlatform: Android / PWA Web App\nVersion: 1.0.2\nStatus: Verified & Signed\n\nInstruções:\n1. Descompacte os arquivos no seu celular Android.\n2. Execute o instalador 'RuthStory.apk' ou instale o PWA pelo navegador.\n3. Aproveite histórias exclusivas e áudios diários sem propaganda!"
  );
  res.send(zipContent);
});

// AI Story Generator / Assistant Endpoint
app.post("/api/ai/generate-story", async (req, res) => {
  try {
    const { prompt, genre, style, characterName } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        success: true,
        story: `[Modo Offline] Capítulo de demonstração para ${characterName || "Ruth"}:\n\nO vento soprava suavemente pelas colinas de Belém quando ${characterName || "Ruth"} olhou para o horizonte dourado. A jornada até ali fora repleta de escolhas corajosas e promessas inabaláveis. Cada grão de trigo colhido nos campos parecia contar uma história de redenção e sabedoria que ecoaria por gerações.`,
        title: `A Jornada de ${characterName || "Ruth"}: ${genre || "Esperança"}`,
      });
    }

    const systemInstruction = `Você é o escritor oficial do aplicativo "RUTH STORY", um famoso autor de sagas inspiradoras, históricas e dramáticas com toque de sabedoria e emoção profunda (foco em cultura bíblica, romances históricos esuperação). Escreva em Português do Brasil de forma poética, envolvente e rica em detalhes emocionais.`;

    const userPrompt = `Crie um capítulo emocionante de história sobre o tema: "${prompt || "Uma nova jornada de esperança e recomeço"}".
Gênero: ${genre || "Romance Histórico"}
Personagem Principal: ${characterName || "Ruth"}
Estilo de Narrativa: ${style || "Envolvente, poética e inspiradora"}.

Retorne em formato JSON com as chaves:
- "title": título do capítulo
- "synopsis": resumo curto de 2 frases
- "content": texto completo do capítulo (com cerca de 4 a 6 parágrafos ricos)
- "moral": uma reflexão inspiradora no final`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ success: true, ...parsed });
  } catch (error: any) {
    console.error("Error generating story:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao gerar história" });
  }
});

// AI Audio / Narration Endpoint (TTS)
app.post("/api/ai/narrate", async (req, res) => {
  try {
    const { text, voice = "Kore" } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        success: false,
        message: "Chave Gemini não configurada para sintetização de voz nativa.",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Leia com voz suave, poética e inspiradora: ${text.slice(0, 400)}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return res.json({ success: true, audioBase64: base64Audio, mimeType: "audio/pcm;rate=24000" });
    } else {
      return res.status(500).json({ success: false, message: "Falha na conversão de áudio" });
    }
  } catch (error: any) {
    console.error("Error generating speech:", error);
    res.status(500).json({ success: false, error: error.message || "Erro no áudio" });
  }
});

// AI Cover Art Generator
app.post("/api/ai/generate-cover", async (req, res) => {
  try {
    const { prompt } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        success: false,
        message: "Chave Gemini não configurada para geração de imagem.",
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-image",
      contents: {
        parts: [
          {
            text: `Atmospheric oil painting book cover art, elegant and historical: ${prompt}. Golden lighting, cinematic composition, masterwork illustration.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4",
        },
      },
    });

    let imageUrl = null;
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
        break;
      }
    }

    if (imageUrl) {
      return res.json({ success: true, imageUrl });
    } else {
      return res.status(500).json({ success: false, message: "Imagem não retornada." });
    }
  } catch (error: any) {
    console.error("Error generating cover image:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao gerar capa" });
  }
});

// Setup Vite / Static handling
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
