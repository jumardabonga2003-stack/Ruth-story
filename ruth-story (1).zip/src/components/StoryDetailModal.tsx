import React, { useState } from 'react';
import { 
  X, Play, BookOpen, Star, Download, Heart, Share2, MessageSquare, 
  Sparkles, CheckCircle2, User, Send, Volume2 
} from 'lucide-react';
import { Story, Comment } from '../types';
import { INITIAL_COMMENTS } from '../data/stories';

interface StoryDetailModalProps {
  story: Story;
  onClose: () => void;
  onOpenReader: (chapterIdx: number) => void;
  isFavorite: boolean;
  onToggleFavorite: (storyId: string) => void;
}

export const StoryDetailModal: React.FC<StoryDetailModalProps> = ({
  story,
  onClose,
  onOpenReader,
  isFavorite,
  onToggleFavorite,
}) => {
  const [comments, setComments] = useState<Comment[]>(
    INITIAL_COMMENTS.filter((c) => c.storyId === story.id || c.storyId === 'ruth-saga-principal')
  );
  const [newCommentText, setNewCommentText] = useState('');
  const [authorNameInput, setAuthorNameInput] = useState('');
  const [isDownloaded, setIsDownloaded] = useState(false);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      storyId: story.id,
      authorName: authorNameInput.trim() || 'Leitor Ruth Story',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
      text: newCommentText.trim(),
      date: 'Agora mesmo',
      likes: 1,
      verifiedReader: true,
    };

    setComments([newComment, ...comments]);
    setNewCommentText('');
  };

  const handleSimulateDownload = () => {
    setIsDownloaded(true);
    setTimeout(() => {
      alert(`História "${story.title}" baixada para leitura offline no aplicativo RUTH STORY!`);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-3xl bg-[#111111] border border-white/10 rounded-[32px] shadow-2xl overflow-hidden relative my-auto animate-fade-in">
        
        {/* Top Header Controls */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 bg-black/70 hover:bg-black text-white p-2.5 rounded-full border border-white/10 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Cover Banner */}
        <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-[#080808]">
          <img
            src={story.coverUrl}
            alt={story.title}
            className="w-full h-full object-cover opacity-50 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/60 to-transparent" />
          
          <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-[#25D366] text-black text-[9px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full">
                  {story.category}
                </span>
                {story.isExclusive && (
                  <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                    Exclusivo
                  </span>
                )}
              </div>
              <h1 className="text-3xl sm:text-5xl font-black font-syne text-white uppercase tracking-tight leading-tight">
                {story.title}
              </h1>
              <p className="text-xs uppercase tracking-widest text-white/50 mt-1 font-semibold">Por {story.author}</p>
            </div>

            <button
              onClick={() => onToggleFavorite(story.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold uppercase tracking-wider border transition-all ${
                isFavorite
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-black/60 text-white border-white/20 hover:bg-black'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-400 text-rose-400' : ''}`} />
              <span>{isFavorite ? 'Favoritado' : 'Favoritar'}</span>
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6 sm:p-8 space-y-8">
          
          {/* Quick Stats & Primary Action */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-[#161616] p-5 rounded-[24px] border border-white/5">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-1.5 text-amber-400 font-black text-sm">
                <Star className="w-4 h-4 fill-amber-400" />
                <span>{story.rating}</span>
              </div>
              <div className="text-xs text-white/50 font-mono">
                <strong className="text-white font-bold">{story.readCount.toLocaleString('pt-BR')}</strong> leituras
              </div>
              <div className="text-xs text-white/50 font-mono">
                <strong className="text-white font-bold">{story.chapters.length}</strong> cap.
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={handleSimulateDownload}
                className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider border transition-all ${
                  isDownloaded
                    ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                    : 'bg-[#202020] text-white border-white/10 hover:bg-[#282828]'
                }`}
              >
                <Download className="w-4 h-4 text-[#25D366]" />
                <span>{isDownloaded ? 'Salvo Offline' : 'Baixar Capítulo'}</span>
              </button>

              <button
                onClick={() => onOpenReader(0)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-black font-black uppercase tracking-[0.1em] px-6 py-3 rounded-xl text-xs sm:text-sm shadow-xl shadow-[#25D366]/20 transition-all hover:scale-[1.02] active:scale-95"
              >
                <BookOpen className="w-4 h-4 stroke-[2.5]" />
                <span>Iniciar Leitura</span>
              </button>
            </div>
          </div>

          {/* Synopsis */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#25D366] mb-2">
              Sinopse da História
            </h3>
            <p className="text-white/70 text-sm sm:text-base leading-relaxed font-sans border-l-2 border-[#25D366]/40 pl-4">
              {story.synopsis}
            </p>
          </div>

          {/* Chapters List */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#25D366] mb-3 flex items-center justify-between">
              <span>Capítulos Disponíveis ({story.chapters.length})</span>
            </h3>

            <div className="space-y-2.5">
              {story.chapters.map((chap, idx) => (
                <div
                  key={chap.id}
                  onClick={() => onOpenReader(idx)}
                  className="flex items-center justify-between p-4 rounded-2xl bg-[#161616] hover:bg-[#202020] border border-white/5 hover:border-[#25D366]/40 cursor-pointer transition-all group"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-[#25D366]/10 border border-[#25D366]/30 text-[#25D366] font-black text-xs flex items-center justify-center shrink-0">
                      {chap.chapterNumber}
                    </div>
                    <div className="truncate">
                      <h4 className="text-sm font-bold text-white group-hover:text-[#25D366] transition-colors truncate uppercase font-syne">
                        {chap.title}
                      </h4>
                      <p className="text-xs text-white/40 truncate font-mono">{chap.estimatedReadTime}</p>
                    </div>
                  </div>

                  <button className="p-2.5 rounded-xl bg-[#222222] group-hover:bg-[#25D366] text-white group-hover:text-black transition-all shrink-0">
                    <Play className="w-4 h-4 fill-current" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Reader Community & Reviews */}
          <div className="border-t border-white/5 pt-6">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#25D366] mb-4 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              <span>Avaliações e Comentários dos Leitores</span>
            </h3>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="mb-6 bg-[#161616] p-4 rounded-[20px] border border-white/5 space-y-3">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Seu Nome (opcional)"
                  value={authorNameInput}
                  onChange={(e) => setAuthorNameInput(e.target.value)}
                  className="bg-[#202020] border border-white/10 text-xs text-white px-3 py-2 rounded-lg focus:outline-none focus:border-[#25D366]"
                />
              </div>
              <textarea
                rows={2}
                placeholder="O que você achou desta história? Deixe sua mensagem de fé e reflexão..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="w-full bg-[#202020] border border-white/10 text-xs text-white p-3 rounded-xl focus:outline-none focus:border-[#25D366]"
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-black text-xs font-black uppercase tracking-wider px-5 py-2.5 rounded-xl transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Publicar Avaliação</span>
                </button>
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-3">
              {comments.map((c) => (
                <div key={c.id} className="p-4 rounded-2xl bg-[#161616] border border-white/5 flex items-start gap-3">
                  <img src={c.avatar} alt={c.authorName} className="w-9 h-9 rounded-full object-cover border border-white/10" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">{c.authorName}</span>
                        {c.verifiedReader && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#25D366]" />
                        )}
                      </div>
                      <span className="text-[10px] text-white/40 font-mono">{c.date}</span>
                    </div>
                    <p className="text-xs text-white/70 leading-relaxed">{c.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
