import { Story, AppRelease } from '../types';

export const INITIAL_STORIES: Story[] = [
  {
    id: 'ruth-saga-principal',
    title: 'RUTH: A Saga da Fidelidade',
    synopsis: 'A emocionante história da mulher moabita que deixou sua terra por amor e fé, selando seu destino nos campos de trigo de Belém.',
    coverUrl: 'https://images.unsplash.com/photo-1509021436468-d510300e5720?auto=format&fit=crop&w=800&q=80',
    category: 'Saga Principal',
    author: 'Equipe Ruth Story',
    rating: 4.9,
    readCount: 14850,
    audioAvailable: true,
    isExclusive: true,
    publishedDate: '15 de Julho, 2026',
    tags: ['Histórico', 'Bíblico', 'Inspirador', 'Amor Leal'],
    chapters: [
      {
        id: 'cap-1',
        chapterNumber: 1,
        title: 'Capítulo I: Nas Terras de Moabe',
        estimatedReadTime: '5 min de leitura',
        synopsis: 'A seca assola Belém, e a família de Elimeleque busca refúgio nas planícies de Moabe, selando laços inesperados.',
        content: `A poeira dourada de Moabe dançava ao vento do entardecer enquanto Ruth observava o horizonte distante. As montanhas de Judá erguiam-se como silhuetas azuis no oeste, separadas pelo espelho prateado do Mar Morto.

Foi naquele vale que ela conheceu Malom. Ele chegara com sua mãe Noemi e seu irmão Quiliom, fugindo da fome implacável que castigava a terra de Judá. Ruth lembrou-se do som das palavras em hebraico, da maneira respeitosa com que tratavam os anciãos e do olhar atento de Noemi.

— Seu Deus é um Deus que guarda promessas — dissera Ruth uma noite, sob as estrelas cintilantes do deserto.

O casamento trouxe anos de alegria simples, colheitas compartilhadas e conversas ao redor do fogo. Mas a tragédia não pede licença. Em um piscar de olhos de apenas um ano, as três mulheres — Noemi, Orfa e Ruth — viram-se desprovidas de seus maridos. O silêncio na casa de pedra de Moabe tornou-se um fardo pesado.

Quando as notícias de que o Senhor visitara Seu povo em Judá danto-lhes pão chegaram aos ouvidos de Noemi, a idosa senhora decidiu retornar a Belém.

— Vão, minhas filhas, voltem para a casa de suas mães — suplicou Noemi com lágrimas nos olhos sulcados pelo tempo. — O Senhor use de misericórdia para convosco, como usastes com os falecidos e comigo.

Orfa chorou, beijou a sogra e, com o coração partido, tomou o caminho de volta aos seus deuses e ao seu povo. Mas Ruth permaneceu imóvel. Seus pés pareciam enraizados no solo de rochas finas.

— Não me instes para que te deixe — pronunciou Ruth, com uma voz firme que ecoaria através dos séculos. — Onde quer que fores, irei eu; e onde quer que pousares, ali pousarei. O teu povo será o meu povo, e o teu Deus o meu Deus. Onde quer que morreres, ali morrerei eu, e ali serei sepultada.`
      },
      {
        id: 'cap-2',
        chapterNumber: 2,
        title: 'Capítulo II: O Caminho para Belém',
        estimatedReadTime: '6 min de leitura',
        synopsis: 'A longa jornada de retorno e a chegada da viúva e sua nora durante a colheita da cevada.',
        content: `As duas mulheres caminharam por estradas íngremes e vales pedregosos. A jornada até Belém exigia coragem; ladrões espreitavam nos desfiladeiros e o sol da tarde queimava impiedosamente.

Ruth sustentava os passos cansados de Noemi, dividindo o último gole de água e consolando-a quando as lembranças da família perdida vinham à tona. Quando finalmente avistaram as muralhas de Belém de Judá, a cidade inteira se comoveu.

 As mulheres saíram às portas, surpresas:
— Não é esta Noemi?

Mas Noemi balançou a cabeça triste:
— Não me chameis Noemi, que significa 'agradável'. Chamai-me Mara, 'amarga', porque o Todo-Poderoso me encheu de amargura. Saí cheia, mas o Senhor me fez voltar vazia.

Contudo, Ruth olhou para os campos que cercavam a cidade. Era o início da colheita da cevada. Os feixes loiros reluziam sob a luz do sol, e o som das foices ressoava como uma melodia de trabalho e abundância.`
      },
      {
        id: 'cap-3',
        chapterNumber: 3,
        title: 'Capítulo III: Nos Campos de Boaz',
        estimatedReadTime: '7 min de leitura',
        synopsis: 'Ruth sai para respigar e encontra a generosidade de Boaz, um homem respeitado e parente remidor.',
        content: `Sem hesitar, Ruth disse a Noemi:
— Deixa-me ir ao campo e respigar atrás daquele a cujos olhos eu achar favor.

Naquela manhã, os passos de Ruth a levaram, por uma providência silenciosa, à propriedade de Boaz, homem valente e próspero da parentela de Elimeleque.

O calor era intenso. Ruth curvature-se repetidamente, recolhendo as espigas que os ceifadores deixavam cair. Seu trabalho era árduo e humilde, mas ela não descansava senão por poucos instantes na cabana.

Ao meio-dia, Boaz chegou da cidade e saudou seus trabalhadores:
— O Senhor seja convosco!
E eles responderam:
— O Senhor te abençoe!

Boaz notou a jovem estrangeira trabalhando incansavelmente no campo.
— De quem é esta moça? — perguntou ao moço encarregado dos ceifadores.

— É a moça moabita que voltou com Noemi das terras de Moabe — respondeu o servo. — Ela nos pediu para respigar entre os feixes e trabalhou desde a manhã até agora.

Boaz aproximou-se de Ruth e disse-lhe com doçura:
— Ouve, minha filha: não vás respigar em outro campo, nem passes daqui; antes, ajunta-te com as minhas moças. Já ordenei aos moços que não te molestem. Quando tiveres sede, vai aos vasos e bebe do que os moços tirarem.

Ruth prostrou-se em terra e perguntou maravilhada:
— Por que achei favor aos teus olhos, para que faças caso de mim, sendo eu uma estrangeira?

Boaz respondeu:
— Já se me contou tudo quanto fizeste por tua sogra, depois da morte de teu marido. O Senhor retribua o teu trabalho, e seja plena a tua recompensa da parte do Senhor, Deus de Israel, sob cujas asas vieste buscar refúgio.`
      },
      {
        id: 'cap-4',
        chapterNumber: 4,
        title: 'Capítulo IV: A Eira e a Promessa',
        estimatedReadTime: '6 min de leitura',
        synopsis: 'A estratégia de Noemi e o ato de coragem e honra na eira sob a noite estrelada.',
        content: `Quando Ruth voltou para casa ao anoitecer com um efa de cevada — uma quantidade extraordinária —, Noemi ficou atônita.

— Onde respigaste hoje? Bendito seja aquele que fez caso de ti!

Ruth contou sobre Boaz, e o rosto de Noemi iluminou-se pela primeira vez em anos:
— Bendito seja ele do Senhor! Esse homem é nosso parente chegado, um dos nossos resgatadores!

À medida que a colheita prosseguia, Noemi instruiu Ruth com sabedoria antiga:
— Minha filha, não devo eu buscar-te um lar para que sejas feliz? Hoje à noite Boaz vai padejar a cevada na eira. Lava-te, unge-te, veste tuas melhores roupas e desce à eira.

Naquela noite calma de celebração, quando Boaz comeu, bebeu e seu coração estava alegre, deitou-se junto a um feixe. Ruth veio de mansinho, descobriu-lhe os pés e deitou-se.

Pela meia-noite, o homem estremeceu e voltou-se; e eis que uma mulher estava deitada aos seus pés.
— Quem és tu? — perguntou ele, sob a penumbra da lua.

— Sou Ruth, tua serva — respondeu ela. — Estende a tua capa sobre a tua serva, porque tu és o resgatador.

Boaz emocionou-se com sua nobreza:
— Bendita sejas tu do Senhor, minha filha! Fizeste melhor a tua última bondade do que a primeira, pois não foste atrás dos jovens, quer pobres quer ricos. Agora, pois, minha filha, não temas; tudo quanto disseste te farei, pois toda a cidade do meu povo sabe que és mulher virtuosa.`
      },
      {
        id: 'cap-5',
        chapterNumber: 5,
        title: 'Capítulo V: A Redenção de Belém',
        estimatedReadTime: '8 min de leitura',
        synopsis: 'O julgamento na porta da cidade, o resgate público e o nascimento de Obede.',
        content: `Na manhã seguinte, Boaz subiu à porta da cidade e assentou-se ali com dez anciãos de Belém. Diante de todas as testemunhas, ele apresentou a causa do resgate da propriedade de Elimeleque e do direito de tomar Ruth por esposa para suscitar o nome do falecido sobre a sua herança.

O parente mais próximo declinou do direito por medo de prejudicar sua própria herança, tirando o sapato e entregando-o a Boaz — a antiga tradição de confirmação de resgate em Israel.

Boaz declarou solemnemente:
— Vós sois hoje testemunhas de que comprei tudo quanto foi de Elimeleque e de seus filhos, e também tomei por mulher a Ruth, a moabita, para suscitar o nome do falecido.

Todo o povo e os anciãos responderam:
— Somos testemunhas! O Senhor faça a esta mulher que entra na tua casa como a Raquel e como a Lia, que ambas edificaram a casa de Israel!

Assim, Boaz tomou Ruth, e ela foi sua esposa. O Senhor abençoou a união, e ela deu à luz um filho.

As mulheres de Belém disseram a Noemi:
— Bendito seja o Senhor, que não te deixou hoje sem resgatador! Ele será renovador da tua vida e consolador da tua velhice, pois tua nora, que te ama e te é melhor do que sete filhos, o deu à luz.

Noemi tomou o menino no colo e tornou-se sua ama. As vizinhas chamavam-no Obede.

Obede foi o pai de Jessé, e Jessé foi o pai de Davi — o grande rei de Israel. E daquela linhagem de fé, coragem e amor nasceria, gerações mais tarde, o Salvador do Mundo.`
      }
    ]
  },
  {
    id: 'o-guardiao-de-belem',
    title: 'O Guardião dos Campos de Belém',
    synopsis: 'A história contada sob o ponto de vista de Boaz: o peso da honra, a liderança em tempos difíceis e a admiração pela virtuosa Ruth.',
    coverUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80',
    category: 'Romance Histórico',
    author: 'Equipe Ruth Story',
    rating: 4.8,
    readCount: 9240,
    audioAvailable: true,
    isExclusive: false,
    publishedDate: '10 de Julho, 2026',
    tags: ['Honra', 'Liderança', 'Boaz', 'Romance'],
    chapters: [
      {
        id: 'guardiao-cap-1',
        chapterNumber: 1,
        title: 'Capítulo I: O Peso da Colheita',
        estimatedReadTime: '5 min de leitura',
        synopsis: 'Boaz observa a terra abençoada após a longa seca e nota uma presença extraordinária entre os servos.',
        content: `Para Boaz, a terra de Belém era mais do que solo e sementes — era a promessa ancestral gravada na memória de seu povo. Anos de aridez haviam esgotado os celeiros e testado a fé de todos.

Agora, o cheiro de cevada fresca preenchia a brisa do amanhecer. Mas entre as dezenas de respigadores na encosta do monte, uma figura destacava-se. Não pelo traje, que era humilde e surrado pela poeira da viagem, mas pela dignidade incansável de seus movimentos.

— Quem é aquela moça? — perguntou ele ao seu encarregado.

A resposta veio cheia de respeito:
— É a moabita que veio com Noemi. Ela não parou desde o raiar do dia.`
      }
    ]
  },
  {
    id: 'o-renascer-de-noemi',
    title: 'O Renascer de Noemi',
    synopsis: 'De Mara a Noemi: uma jornada profunda sobre cura do luto, restauração da esperança e o poder da lealdade familiar.',
    coverUrl: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=800&q=80',
    category: 'Reflexões',
    author: 'Ruth Story Devocional',
    rating: 4.9,
    readCount: 11200,
    audioAvailable: true,
    isExclusive: true,
    publishedDate: '1 de Julho, 2026',
    tags: ['Cura Emocional', 'Superação', 'Fé', 'Noemi'],
    chapters: [
      {
        id: 'noemi-cap-1',
        chapterNumber: 1,
        title: 'Capítulo I: O Silêncio das Perdas',
        estimatedReadTime: '4 min de leitura',
        synopsis: 'Como transformar a dor das perdas na certeza de que Deus trabalha no invisível.',
        content: `Houve noites em Moabe nas quais Noemi acreditou que a alvorada jamais voltaria a brilhar. Perder o marido e os dois filhos em solo estrangeiro parecia o fim absoluto de qualquer esperança.

No entanto, em meio à cinza da dor, uma semente de lealdade germinou. A presença incondicional de Ruth foi o abraço visível de Deus em meio ao luto. Quando choramos no silêncio, muitas vezes não percebemos que o Criador já está preparando o resgate das nossas vidas.`
      }
    ]
  },
  {
    id: 'audiobook-promessa-no-campo',
    title: 'Audiobook: A Promessa no Campo de Trigo',
    synopsis: 'Superprodução em áudio com narração poética, trilha sonora orquestral e efeitos sonoros imersivos das noites de Judá.',
    coverUrl: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&w=800&q=80',
    category: 'Audiobook',
    author: 'Ruth Story Audio',
    rating: 5.0,
    readCount: 18500,
    audioAvailable: true,
    isExclusive: true,
    publishedDate: '18 de Julho, 2026',
    tags: ['ÁudioImersivo', 'Audiobook', 'Narrações'],
    chapters: [
      {
        id: 'audio-cap-1',
        chapterNumber: 1,
        title: 'Episódio Especial: O Cântico das Vindimadoras',
        estimatedReadTime: '12 min de áudio',
        synopsis: 'Experiência sonora guiada pelas colinas de Belém ao pôr do sol.',
        content: `Feche os olhos e imagine o farfalhar das folhas ao vento fresco da noite de Judá. O som dos grilos no vale, os passos leves na palha e o sussurro de uma oração de gratidão...

Esta é a narração oficial do audiobook RUTH STORY. Ouça com fones de ouvido para sentir a imersão completa.`
      }
    ]
  }
];

export const OFFICIAL_APP_RELEASE: AppRelease = {
  version: '1.0.2 Oficial',
  buildDate: 'Julho de 2026',
  size: '14.8 MB',
  downloads: 42190,
  changes: [
    'Leitor E-Reader com modo noturno, sépia e ajuste dinâmico de fonte',
    'Audiobook com voz sintetizada de alta fidelidade e player em segundo plano',
    'Download de histórias para leitura 100% offline no celular',
    'Gerador de capítulos com inteligência artificial para continuar histórias',
    'Instalação rápida via PWA ou arquivo zip/apk para Android'
  ],
  downloadUrl: '/api/download/RUTH-STORY.zip'
};

export const INITIAL_COMMENTS = [
  {
    id: 'c1',
    storyId: 'ruth-saga-principal',
    authorName: 'Maria Antônia Santos',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80',
    text: 'Que aplicativo maravilhoso! A história de Ruth me emocionou até as lágrimas. O áudio é super tranquilo de ouvir enquanto cozinho!',
    date: 'Há 2 horas',
    likes: 34,
    verifiedReader: true
  },
  {
    id: 'c2',
    storyId: 'ruth-saga-principal',
    authorName: 'Pastor Marcos Oliveira',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
    text: 'A fidelidade histórica e o respeito bíblico no texto são impressionantes. Recomendei para todos os jovens do meu grupo de leitura!',
    date: 'Há 5 horas',
    likes: 52,
    verifiedReader: true
  },
  {
    id: 'c3',
    storyId: 'o-guardiao-de-belem',
    authorName: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    text: 'Baixei o app pelo link do zip e funcionou perfeitamente no meu celular! A leitura noturna é muito confortável pros olhos.',
    date: 'Ontem',
    likes: 19,
    verifiedReader: true
  }
];
