import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, X, SkipForward, SkipBack, Music } from 'lucide-react';
import { Story, Chapter } from '../types';

interface AudioPlayerBarProps {
  story: Story;
  chapter: Chapter;
  onClose: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({ story, chapter, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(15);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-40 bg-[#161616]/95 backdrop-blur-xl border border-[#25D366]/40 p-4 rounded-2xl shadow-[0_10px_30px_rgba(0,0,0,0.8)] text-slate-100 animate-slide-up">
      <div className="flex items-center justify-between gap-3 mb-2">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 flex items-center justify-center text-[#25D366] shrink-0 animate-pulse">
            <Music className="w-5 h-5" />
          </div>
          <div className="truncate">
            <h4 className="text-xs font-bold text-white truncate">{chapter.title}</h4>
            <p className="text-[11px] text-[#25D366] truncate">{story.title}</p>
          </div>
        </div>

        <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Progress slider */}
      <div className="mb-3">
        <div className="w-full h-1.5 bg-[#252525] rounded-full overflow-hidden cursor-pointer">
          <div 
            style={{ width: `${progress}%` }} 
            className="h-full bg-gradient-to-r from-[#25D366] to-[#1ebe5d] transition-all duration-300"
          />
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
          <span>01:42</span>
          <span>08:30</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between">
        <button 
          onClick={() => setIsMuted(!isMuted)} 
          className="text-slate-400 hover:text-white p-1 text-xs flex items-center gap-1"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-[#25D366]" />}
        </button>

        <div className="flex items-center gap-3">
          <button className="text-slate-400 hover:text-white p-1">
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-10 h-10 rounded-full bg-[#25D366] text-black flex items-center justify-center font-bold shadow-lg shadow-[#25D366]/30 hover:scale-105 transition-transform"
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
          </button>

          <button className="text-slate-400 hover:text-white p-1">
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        <span className="text-[10px] font-bold uppercase tracking-wider text-[#25D366] bg-[#25D366]/10 px-2 py-0.5 rounded-full border border-[#25D366]/30">
          Áudio HD
        </span>
      </div>
    </div>
  );
};
