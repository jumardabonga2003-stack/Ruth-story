import React from 'react';
import { BookOpen, Download, Sparkles, Heart, Search, BookMarked, Smartphone } from 'lucide-react';

interface NavbarProps {
  activeTab: 'library' | 'download' | 'favorites' | 'studio';
  setActiveTab: (tab: 'library' | 'download' | 'favorites' | 'studio') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  favoritesCount: number;
  onOpenReaderForFeatured: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  favoritesCount,
  onOpenReaderForFeatured,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#080808]/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Branding - Bold Typography theme */}
          <div 
            onClick={() => setActiveTab('library')} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 bg-[#25D366] rounded-xl flex items-center justify-center text-black font-black text-xl italic shadow-lg shadow-[#25D366]/20 group-hover:scale-105 transition-transform shrink-0">
              R
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="font-syne text-lg font-black tracking-[0.2em] uppercase text-white group-hover:text-[#25D366] transition-colors">
                  RUTH STORY
                </span>
                <span className="text-[9px] bg-[#25D366]/15 text-[#25D366] font-bold px-2 py-0.5 rounded-full border border-[#25D366]/40 uppercase tracking-widest">
                  Oficial
                </span>
              </div>
              <span className="text-[10px] uppercase tracking-widest text-white/40 font-semibold hidden sm:block">
                Publishing Suite & Reader
              </span>
            </div>
          </div>

          {/* Search Bar (Desktop) */}
          <div className="hidden md:flex items-center flex-1 max-w-xs mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <input
                type="text"
                placeholder="Buscar histórias, capítulos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#111111] border border-white/10 focus:border-[#25D366] text-xs font-medium text-white pl-9 pr-4 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#25D366] transition-all"
              />
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="flex items-center gap-1 sm:gap-3">
            <button
              onClick={() => setActiveTab('library')}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-[11px] font-bold uppercase tracking-[0.15em] transition-all ${
                activeTab === 'library'
                  ? 'bg-[#161616] text-[#25D366] border border-[#25D366]/40 shadow-sm'
                  : 'text-white/60 hover:text-white hover:bg-[#111111]'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Biblioteca</span>
            </button>

            <button
              onClick={() => setActiveTab('studio')}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-[11px] font-bold uppercase tracking-[0.15em] transition-all ${
                activeTab === 'studio'
                  ? 'bg-[#161616] text-[#25D366] border border-[#25D366]/40 shadow-sm'
                  : 'text-white/60 hover:text-white hover:bg-[#111111]'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Criador IA</span>
            </button>

            <button
              onClick={() => setActiveTab('favorites')}
              className={`relative flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-[11px] font-bold uppercase tracking-[0.15em] transition-all ${
                activeTab === 'favorites'
                  ? 'bg-[#161616] text-[#25D366] border border-[#25D366]/40 shadow-sm'
                  : 'text-white/60 hover:text-white hover:bg-[#111111]'
              }`}
            >
              <Heart className="w-4 h-4 text-rose-400" />
              <span className="hidden sm:inline">Favoritos</span>
              {favoritesCount > 0 && (
                <span className="ml-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[9px] px-1.5 py-0.2 rounded-full font-bold">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Direct App Reader Action */}
            <button
              onClick={onOpenReaderForFeatured}
              className="hidden lg:flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-[11px] font-bold uppercase tracking-[0.15em] text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 hover:bg-emerald-900/50 transition-all"
            >
              <BookMarked className="w-4 h-4" />
              <span>Ler Agora</span>
            </button>

            {/* Download App Official Button */}
            <button
              onClick={() => setActiveTab('download')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-[0.15em] transition-all shadow-xl ${
                activeTab === 'download'
                  ? 'bg-[#1ebe5d] text-black ring-2 ring-[#25D366]'
                  : 'bg-[#25D366] text-black hover:bg-[#1ebe5d] hover:scale-[1.02] active:scale-95 shadow-[#25D366]/20'
              }`}
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>Baixar App</span>
            </button>
          </nav>
        </div>

        {/* Mobile Search Input */}
        <div className="pb-3 md:hidden">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            <input
              type="text"
              placeholder="Buscar histórias..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111111] border border-white/10 focus:border-[#25D366] text-xs text-white pl-9 pr-4 py-2 rounded-xl focus:outline-none"
            />
          </div>
        </div>
      </div>
    </header>
  );
};
